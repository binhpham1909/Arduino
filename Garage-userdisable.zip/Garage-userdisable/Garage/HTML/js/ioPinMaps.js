var outputPins = {"GPIO-15":15,"GPIO-99":99};
var inputPins = {"GPIO-4":4,"GPIO-5":5,"GPIO-14":14};
var buttonPins = {"GPIO-2":2,"GPIO-12":12,"GPIO-13":13};