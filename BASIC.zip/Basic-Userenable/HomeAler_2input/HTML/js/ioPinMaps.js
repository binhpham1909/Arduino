var outputPins = {"GPIO-2":2,"GPIO-15":15,"GPIO-14":14,"GPIO-99":99};
var inputPins = {"GPIO-4":4,"GPIO-5":5};
var buttonPins = {"GPIO-12":12,"GPIO-13":13};